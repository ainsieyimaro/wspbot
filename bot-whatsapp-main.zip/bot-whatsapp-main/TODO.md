### Genral
- [X] __(doc)__ Video de como colaborar PR
- [ ] __(doc)__ Video implementación de test y cobertura
- [ ] __(doc)__ Video explicacion de github action
- [ ] Crear packages list externas

### @bot-whatsapp/bot
- [X] agregar export package
- [X] Posibilidad de en el capture meter todo un nuevo CTX  de FLOW .addAnswer('Marca la opcion',{capture:true, join:CTX})
- [X] .addKeyword('1') no funciona con 1 caracter
- [X] sensitivy viene activado por defecto
- [X] fallback respuesta en hijo: Se puede colocar en option el ref de la answer fallback
- [X] Cuando Envian Sticket devuelve mensaje raro
- [x] addAnswer agregar delay
- [ ] colocar mensaje esperando conectando whatsapp (provider)
- [ ] createDatabase validar implementacion de funciones
- [ ] limitar caracteres de mensajes 4000
- [X] cuando envias numeros (5 o 1) se dispara el flujo

### @bot-whatsapp/database
- [X] agregar export package
- [X] __(doc):__ Video para explicar como implementar nuevos database
- [X] Mongo adapter
- [X] MySQL adapter
- [ ] JsonFile adapter

### @bot-whatsapp/provider
- [X] agregar export package
- [ ] __(doc):__ Video para explicar como implementar nuevos providers
- [X] WhatsappWeb provider enviar imagenes
- [X] WhatsappWeb provider enviar audio
- [X] WhatsappWeb botones (Tiene truco) github:leifermendez/whatsapp-web.js
- [ ] Twilio adapter
- [ ] Meta adapter

### @bot-whatsapp/cli
- [X] Hacer comando para crear `example-app`


### @bot-whatsapp/create-bot
- [ ] 

### Starters
- [X] Base
- [X] Basico
- [ ] Enviando Imagen
- [ ] Enviando Botones
- [ ] Mezclando flujos hijos

### Extra
- [X] Crear CI mantener fork update https://stackoverflow.com/questions/23793062/can-forks-be-synced-automatically-in-github
