const { startInteractive } = require('../cli')
/**
 * Voy a llamar directo a CLI
 * Temporalmente luego mejoro esta
 * parte
 * @returns
 */
const main = () => startInteractive()

module.exports = main
