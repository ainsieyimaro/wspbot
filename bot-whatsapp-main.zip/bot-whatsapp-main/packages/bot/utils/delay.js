const delay = (miliseconds) => new Promise((res) => setTimeout(res, miliseconds))

module.exports = { delay }
