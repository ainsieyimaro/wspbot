const addAction = () => async () => {}

module.exports = { addAction }
