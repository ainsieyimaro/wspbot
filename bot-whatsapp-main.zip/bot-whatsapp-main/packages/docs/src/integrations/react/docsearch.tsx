
// import { qwikify$ } from '@builder.io/qwik-react';
// import { DocSearch } from '@docsearch/react';
// import { component$ } from '@builder.io/qwik';

// export const DocSearch$ = qwikify$(DocSearch);

// export const Algolia = component$(() => {
//     return(
//         <>
//           <div class="">
//                 <DocSearch$
//                 appId="3G2WXK7FDH"
//                 apiKey="0a551503db005c5575ddb5fd5a7fbf50"
//                 indexName="bot"
//                 />
//             </div>
//         </>
//     )
// })