export const SITE = {
  name: "Qwind",

  origin: "https://qwind.pages.dev",
  basePathname: "/",
  trailingSlash: true
};
